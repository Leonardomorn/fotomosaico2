# fotomosaico2
# Trabalho feito por Leonardo da Silva Camargo
# GRR 20203903
# para gerar o executável, digite make
# o programa necessita de um diretório de pastilhas em formato ppm
# é necessário também uma imagem como entrada em -i em formato ppm
# -p e -o são argumentos opcionais 
# -p escolhe um diretório de pastilhas em formato ppm (caso não colocado é atribuído tiles como padrão)
# -o cria um arquivo foto mosaico, o nome deve ter ".ppm" no final, exemplo "imagem.ppm" (caso não colocado é atribuido defaultoutput.ppm como padrão)
